/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.beans.PropertyChangeSupport;

/**
 *
 * @author Proyectos
 */
public class Divisa {

    private double valor;
    private String nombre;
    private PropertyChangeSupport propertySupport;

    //Constructor con propiedades
    public Divisa(double valor, String nombre) {
        this.valor = valor;
        this.nombre = nombre;
    }

    //Constructor con soporte de cambio de propiedades
    public Divisa() {
        propertySupport = new PropertyChangeSupport(this);
    }

    public void setNombre(String Nombre) {
        nombre = Nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setValor(double Valor) {
        valor = Valor;
    }

    public double getValor() {
        return valor;
    }

}
